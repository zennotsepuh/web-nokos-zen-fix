create table if not exists profiles (id uuid primary key references auth.users(id) on delete cascade, email text, role text default 'user', balance numeric(14,2) default 0, created_at timestamptz default now());

alter table profiles enable row level security;
create policy "read own profile" on profiles for select using (auth.uid() = id);
