import Link from "next/link";

export default function Home() {
  return (
    <main>
      <section className="hero container">
        <div>
          <span className="eyebrow">⚡ FAST • SECURE • AUTOMATED</span>
          <h1>Order NOKOS.<br /><span style={{ color: "#8b5cf6" }}>Cepat & simpel.</span></h1>
          <p>Platform order nomor virtual dengan server, negara, operator, deposit dan status order melalui API provider.</p>
          <div className="actions"><Link className="btn" href="/register">Buat Akun</Link><Link className="btn secondary" href="/login">Login</Link></div>
        </div>
        <div className="card"><div className="muted">Saldo tersedia</div><div className="balance">Rp 0</div><div className="muted">Siap digunakan untuk order nomor.</div><div className="actions"><Link className="btn" href="/deposit">+ Deposit</Link></div></div>
      </section>
      <section className="section container"><h2>Fitur</h2><div className="grid">
        <div className="card"><h3>⚡ Order cepat</h3><p className="muted">Proxy server-side ke API provider.</p></div>
        <div className="card"><h3>🔐 API aman</h3><p className="muted">API key tidak ditaruh di browser.</p></div>
        <div className="card"><h3>📩 Status OTP</h3><p className="muted">Cek status order dari dashboard.</p></div>
      </div></section>
    </main>
  );
}
