"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { supabaseBrowser } from "../../lib/supabase";

export default function RegisterPage() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [message, setMessage] = useState("");
  const router = useRouter();

  async function submit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setMessage("");
    try {
      const { error } = await supabaseBrowser().auth.signUp({ email, password });
      if (error) throw error;
      setMessage("Akun berhasil dibuat. Mengalihkan ke login...");
      setTimeout(() => router.push("/login"), 1000);
    } catch (e) {
      setMessage(e instanceof Error ? e.message : "Pendaftaran gagal");
    }
  }

  return <main className="container"><form className="card form" onSubmit={submit}><h2>Buat Akun</h2><div className="field"><label>Email</label><input type="email" value={email} onChange={e=>setEmail(e.target.value)} required /></div><div className="field"><label>Password</label><input type="password" value={password} onChange={e=>setPassword(e.target.value)} minLength={6} required /></div>{message&&<p className="muted">{message}</p>}<button className="btn" type="submit">Daftar</button></form></main>;
}
