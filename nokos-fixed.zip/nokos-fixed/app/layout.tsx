import "./globals.css";
import Link from "next/link";

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="shell">
      <nav className="nav">
        <Link className="brand" href="/">NO<span>KOS</span></Link>
        <div className="navlinks">
          <Link href="/dashboard">Dashboard</Link>
          <Link href="/orders">Order</Link>
          <Link href="/deposit">Deposit</Link>
          <Link href="/history">History</Link>
          <Link href="/profile">Profile</Link>
        </div>
        <Link className="btn" href="/dashboard">Mulai Order</Link>
      </nav>
      {children}
      <footer className="footer"><div className="container">NOKOS Order Center · 2026</div></footer>
    </div>
  );
}
