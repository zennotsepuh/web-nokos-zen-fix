"use client";
import Link from "next/link";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { supabaseBrowser } from "../../lib/supabase";

export default function LoginPage() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const router = useRouter();

  async function submit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setError("");
    try {
      const { error } = await supabaseBrowser().auth.signInWithPassword({ email, password });
      if (error) throw error;
      router.push("/dashboard");
    } catch (e) {
      setError(e instanceof Error ? e.message : "Login gagal");
    }
  }

  return <main className="container"><form className="card form" onSubmit={submit}><h2>Login</h2><div className="field"><label>Email</label><input type="email" value={email} onChange={e=>setEmail(e.target.value)} required /></div><div className="field"><label>Password</label><input type="password" value={password} onChange={e=>setPassword(e.target.value)} required /></div>{error&&<p className="error">{error}</p>}<button className="btn" type="submit">Masuk</button><p className="muted">Belum punya akun? <Link href="/register">Daftar</Link></p></form></main>;
}
