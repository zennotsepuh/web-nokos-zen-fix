"use client";
import Link from "next/link";
import { useEffect, useState } from "react";

type Country = { code?: string|number; id?: string|number; value?: string|number; name?: string; country?: string };
function arrayFrom(data: any): any[] { if (Array.isArray(data)) return data; if (Array.isArray(data?.data)) return data.data; return []; }

export default function DashboardPage() {
  const [server,setServer]=useState("1");
  const [countries,setCountries]=useState<Country[]>([]);
  const [loading,setLoading]=useState(false);
  const [error,setError]=useState("");
  useEffect(()=>{ void load(); },[server]);
  async function load(){ setLoading(true); setError(""); try { const res=await fetch(`/api/countries?server=${server}`); const json=await res.json(); if(!json.ok) throw new Error(json.error||"Gagal memuat negara"); setCountries(arrayFrom(json.data)); } catch(e){setError(e instanceof Error?e.message:"Gagal memuat negara");} finally{setLoading(false);} }
  return <main className="container section"><div style={{display:"flex",justifyContent:"space-between",gap:10,alignItems:"center"}}><div><span className="eyebrow">DASHBOARD</span><h1>Order NOKOS</h1></div><Link className="btn" href="/deposit">Top Up</Link></div><div className="card" style={{margin:"20px 0"}}><div className="muted">Saldo aplikasi</div><div className="balance">Rp 0</div><small className="muted">Saldo wallet lokal akan diaktifkan setelah database billing disambungkan.</small></div><div className="field" style={{maxWidth:260}}><label>Server</label><select value={server} onChange={e=>setServer(e.target.value)}>{[1,2,3,4].map(x=><option key={x} value={x}>Server {x}</option>)}</select></div>{loading&&<p className="muted">Memuat negara...</p>}{error&&<p className="error">{error}</p>} {!loading&&!error&&<div className="grid">{countries.map((c,i)=>{const code=c.code??c.id??c.value??"";return <Link className="card" href={`/orders?server=${server}&country=${encodeURIComponent(String(code))}`} key={`${code}-${i}`}><b>{c.name??c.country??`Country ${code||i+1}`}</b><div className="muted">Kode: {code||"-"}</div></Link>})}</div>}</main>;
}
