import { NextRequest } from "next/server";
import { ditz } from "../../../lib/ditznesia";
import { ok, fail } from "../../../lib/api";

export async function GET(request: NextRequest) {
  try {
    const params: Record<string, string> = {};
    request.nextUrl.searchParams.forEach((value, key) => { params[key] = value; });
    return ok(await ditz("countries", params));
  } catch (error) {
    return fail(error);
  }
}
