import { NextRequest } from "next/server";
import { ditz } from "../../../lib/ditznesia";
import { ok, fail } from "../../../lib/api";

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    return ok(await ditz("order", body));
  } catch (error) {
    return fail(error);
  }
}
